================================================================================
FORGE - OPERATING MANUAL
================================================================================
 
Welcome to Forge!
 
Forge is a professional USB drive utility designed for formatting, testing,
repairing, and benchmarking removable storage devices.
 
This guide contains the necessary steps to install, configure, and operate
Forge on a Windows environment.
 
--------------------------------------------------------------------------------
1. REQUIREMENTS
--------------------------------------------------------------------------------
 
To run Forge on Windows, the following components must be installed:
 
• Python 3.10 or newer
Download:
https://www.python.org/
 
CRITICAL STEP:
During installation, ensure that the following option is enabled:
 
[✓] Add Python.exe to PATH
 
• Administrator Privileges
Some Forge utilities require elevated permissions for direct disk access.
 
• Supported Operating Systems
 
Windows 10
Windows 11
 
--------------------------------------------------------------------------------
2. REQUIRED DEPENDENCIES
--------------------------------------------------------------------------------
 
Forge requires the following Python packages:
 
psutil
pywin32
wmi
pyusb
customtkinter
ttkbootstrap
matplotlib
numpy
 
Install all dependencies using:
 
pip install -r requirements.txt
 
Example requirements.txt:
 
customtkinter
ttkbootstrap
psutil
pywin32
wmi
pyusb
matplotlib
numpy
 
--------------------------------------------------------------------------------
3. INSTALLATION & SETUP
--------------------------------------------------------------------------------
 
Follow these steps to install Forge:
 
1. Open Command Prompt or PowerShell.
 
2. Navigate to the Forge folder.
 
cd C:\Users\YourName\Documents\Forge
 
3. Create a virtual environment.
 
python -m venv venv
 
4. Activate the virtual environment.
 
venv\Scripts\activate
 
5. Install all required packages.
 
pip install -r requirements.txt
 
--------------------------------------------------------------------------------
4. OPERATING MANUAL (HOW TO RUN)
--------------------------------------------------------------------------------
 
Once installation has been completed:
 
1. Open Command Prompt or PowerShell.
 
2. Navigate to the Forge directory.
 
cd path\to\forge
 
3. Activate the virtual environment.
 
venv\Scripts\activate
 
4. Launch Forge.
 
python forge.py
 
or
 
python main.py
 
5. The Forge main window will appear.
 
--------------------------------------------------------------------------------
5. FORMAT DRIVE (CLEAN & WIPE)
--------------------------------------------------------------------------------
 
Purpose:
 
• Securely erase USB media
• Remove partitions
• Recreate storage structures
• Restore factory-style formatting
 
Procedure:
 
1. Select target USB device.
2. Choose:
 
Format Drive (Clean & Wipe)
 
3. Select desired file system.
4. Press START.
5. Confirm warning dialog.
 
WARNING:
 
ALL DATA ON THE SELECTED DEVICE WILL BE PERMANENTLY LOST.
 
--------------------------------------------------------------------------------
6. TEST FAKE CAPACITY / BAD SECTORS
--------------------------------------------------------------------------------
 
Purpose:
 
• Detect counterfeit flash drives
• Verify real storage capacity
• Identify damaged sectors
• Evaluate media health
 
Procedure:
 
1. Select target USB device.
2. Choose:
 
Test Fake Capacity / Bad Sectors
 
3. Start scan.
4. Wait for verification process to complete.
 
Note:
 
Large-capacity devices may require considerable scanning time.
 
--------------------------------------------------------------------------------
7. BENCHMARK SPEED (READ / WRITE)
--------------------------------------------------------------------------------
 
Purpose:
 
• Measure USB performance
• Compare storage devices
• Validate manufacturer claims
 
Reported Metrics:
 
• Sequential Read Speed
• Sequential Write Speed
• Average Transfer Rate
• Peak Read Speed
• Peak Write Speed
 
Procedure:
 
1. Select target USB device.
2. Choose:
 
Benchmark Speed (Read / Write)
 
3. Click START BENCHMARK.
4. Review generated report.
 
--------------------------------------------------------------------------------
8. REPAIR PARTITIONS & MBR
--------------------------------------------------------------------------------
 
Purpose:
 
• Repair partition tables
• Restore corrupted devices
• Rebuild Master Boot Record (MBR)
• Fix inaccessible USB drives
 
Procedure:
 
1. Select target device.
2. Choose:
 
Repair Partitions & MBR
 
3. Confirm repair operation.
4. Wait for completion.
 
Administrator privileges are required.
 
--------------------------------------------------------------------------------
9. TROUBLESHOOTING
--------------------------------------------------------------------------------
 
• "Python is not recognized as an internal or external command"
 
Cause:
Python is not installed or PATH is not configured.
 
Solution:
Reinstall Python and enable:
 
[✓] Add Python.exe to PATH
 
--------------------------------------------------------
 
• "ModuleNotFoundError"
 
Cause:
Missing required package.
 
Solution:
 
pip install -r requirements.txt
 
--------------------------------------------------------
 
• "Access Denied"
 
Cause:
Insufficient permissions.
 
Solution:
Run Forge as Administrator.
 
--------------------------------------------------------
 
• "Device Not Found"
 
Cause:
USB device disconnected or failed.
 
Solution:
Reconnect device and refresh drive list.
 
--------------------------------------------------------------------------------
10. SAFETY RECOMMENDATIONS
--------------------------------------------------------------------------------
 
• Verify the selected device before formatting.
• Backup important data before repair operations.
• Never disconnect a device during active operations.
• Use administrative privileges for advanced functions.
• Safely eject USB devices after all operations complete.
 
================================================================================
END OF DOCUMENT
================================================================================