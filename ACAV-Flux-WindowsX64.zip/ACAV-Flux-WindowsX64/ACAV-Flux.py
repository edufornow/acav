# ================================================================
# FLUX — USB FLASHING SOFTWARE
# A self-contained, Windows-friendly, Rufus-inspired USB imaging GUI
# with a 2000s futuristic / enterprise-software visual language.
#
# Requirements:
#   - Python 3.10+
#   - Standard library only (Tkinter required)
#
# Notes:
#   - Automatically checks and requests Administrator privileges on launch.
#   - FLUX deliberately adds multiple destructive-operation safeguards.
#   - Performs raw image (DD-style) writes using Win32 API volume locking.
#
# ================================================================

from __future__ import annotations

import ctypes
import hashlib
import base64
import json
import os
import platform
import queue
import shutil
import struct
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path
from tkinter import (
    Tk, Toplevel, StringVar, BooleanVar, IntVar, DoubleVar,
    Text, END, DISABLED, NORMAL, WORD, filedialog, messagebox
)
from tkinter import ttk
import tkinter as tk


APP_NAME = "FLUX"
APP_VERSION = "1.0.0"
APP_CHANNEL = "Release"
APP_VENDOR = "ACAV Digital"
APP_TAGLINE = "USB FLASHING SOFTWARE"
CONFIG_DIR_NAME = "Flux"
CONFIG_FILE_NAME = "settings.json"
LOG_FILE_NAME = "flux.log"
DEFAULT_CHUNK_SIZE = 4 * 1024 * 1024
MAX_LOG_LINES = 1200


# ----------------------------- Palette -----------------------------

BG = "#07111f"
PANEL = "#0d1c31"
PANEL_2 = "#11253f"
PANEL_3 = "#152d49"
BORDER = "#2d5e8f"
BORDER_BRIGHT = "#56caff"
TEXT = "#eff8ff"
TEXT_DIM = "#a7bfd7"
TEXT_MUTED = "#738fae"
CYAN = "#36dfff"
CYAN_2 = "#8cf5ff"
BLUE = "#0676ff"
BLUE_2 = "#1aa7ff"
DEEP_BLUE = "#062b71"
NAVY = "#04152f"
GREEN = "#39e58c"
YELLOW = "#ffd15c"
ORANGE = "#ff9c42"
RED = "#ff526c"
SILVER = "#cbd9e7"
BLACK = "#02060b"


# --------------------------- Data models ---------------------------

@dataclass
class DeviceInfo:
    number: int
    name: str
    size: int
    bus: str = "Unknown"
    partition_style: str = "Unknown"
    health: str = "Unknown"
    operational_status: str = "Unknown"
    serial: str = ""
    is_boot: bool = False
    is_system: bool = False
    removable_hint: bool = False
    raw_path: str = ""
    mount_points: list[str] = field(default_factory=list)
    source: str = "unknown"

    @property
    def size_gb(self) -> float:
        return self.size / (1024 ** 3) if self.size else 0.0

    @property
    def display_name(self) -> str:
        suffix = f" • {self.bus}" if self.bus else ""
        return f"{self.name}{suffix}"

    @property
    def safe_label(self) -> str:
        return f"Disk {self.number}: {self.display_name} — {format_bytes(self.size)}"


@dataclass
class FlashPlan:
    image_path: str = ""
    device_number: int | None = None
    write_mode: str = "Raw image (DD)"
    partition_scheme: str = "GPT"
    target_system: str = "UEFI"
    file_system: str = "Large FAT32"
    cluster_size: str = "Default"
    volume_label: str = "FLUX"
    verify: bool = True
    power_protection: bool = True
    quick_format: bool = False
    bad_blocks: bool = False
    bad_block_passes: int = 1


@dataclass
class AppSettings:
    verify_after_write: bool = True
    confirm_phrase_required: bool = True
    chunk_size_mb: int = 4
    animation: bool = True
    autosave_logs: bool = True
    compact_mode: bool = False
    remember_last_iso: bool = False
    last_iso: str = ""
    accent: str = "cyan"


# --------------------------- Utility API ---------------------------

def format_bytes(value: int | float) -> str:
    try:
        value = float(value)
    except Exception:
        return "0 B"
    if value < 1024:
        return f"{int(value)} B"
    if value < 1024 ** 2:
        return f"{value / 1024:.1f} KiB"
    if value < 1024 ** 3:
        return f"{value / (1024 ** 2):.1f} MiB"
    if value < 1024 ** 4:
        return f"{value / (1024 ** 3):.2f} GiB"
    return f"{value / (1024 ** 4):.2f} TiB"


def human_duration(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    if seconds < 1:
        return "<1s"
    if seconds < 60:
        return f"{int(seconds)}s"
    minutes, sec = divmod(int(seconds), 60)
    if minutes < 60:
        return f"{minutes}m {sec}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m"


def timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def config_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home()))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    path = base / CONFIG_DIR_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_path() -> Path:
    return config_dir() / CONFIG_FILE_NAME


def log_path() -> Path:
    return config_dir() / LOG_FILE_NAME


def is_admin() -> bool:
    if os.name != "nt":
        try:
            return os.geteuid() == 0
        except AttributeError:
            return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def is_windows() -> bool:
    return os.name == "nt"


def relaunch_as_administrator() -> bool:
    """Ask Windows UAC to restart FLUX elevated before showing GUI."""
    if not is_windows() or is_admin():
        return True
    try:
        executable = Path(sys.executable)
        if executable.name.lower() == "python.exe":
            pythonw = executable.with_name("pythonw.exe")
            if pythonw.exists():
                executable = pythonw
        script = str(Path(__file__).resolve())
        params = subprocess.list2cmdline([script, *sys.argv[1:]])
        result = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            str(executable),
            params,
            str(Path(__file__).resolve().parent),
            1,
        )
        return int(result) > 32
    except Exception:
        return False


def run_command(args: list[str], timeout: float = 15) -> tuple[int, str, str]:
    proc = subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
        encoding="utf-8",
        errors="replace",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return proc.returncode, proc.stdout, proc.stderr


def json_or_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def parse_int(value, default=0):
    try:
        return int(str(value).strip())
    except Exception:
        return default


def safe_json_load(path: Path, default: dict):
    try:
        if path.exists():
            with path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return dict(default)


def safe_json_save(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)
    temp.replace(path)


# ------------------------- Settings store --------------------------

class SettingsStore:
    def __init__(self):
        self.path = config_path()

    def load(self) -> AppSettings:
        raw = safe_json_load(self.path, {})
        settings = AppSettings()
        for field_name in asdict(settings):
            if field_name in raw:
                try:
                    setattr(settings, field_name, raw[field_name])
                except Exception:
                    pass
        return settings

    def save(self, settings: AppSettings):
        safe_json_save(self.path, asdict(settings))


# ----------------------------- Logging -----------------------------

class FluxLogger:
    def __init__(self, settings: AppSettings):
        self.settings = settings
        self.lines: list[str] = []
        self.lock = threading.Lock()

    def log(self, message: str, level: str = "INFO"):
        line = f"[{timestamp()}] [{level}] {message}"
        with self.lock:
            self.lines.append(line)
            if len(self.lines) > MAX_LOG_LINES:
                self.lines = self.lines[-MAX_LOG_LINES:]
        if self.settings.autosave_logs:
            try:
                with log_path().open("a", encoding="utf-8") as handle:
                    handle.write(line + "\n")
            except Exception:
                pass

    def error(self, message: str):
        self.log(message, "ERROR")

    def warning(self, message: str):
        self.log(message, "WARN")


# ------------------------ Device enumeration ----------------------

class DeviceEnumerator:
    def __init__(self, logger: FluxLogger):
        self.logger = logger

    def enumerate(self) -> list[DeviceInfo]:
        if is_windows():
            devices = self._windows_get_disks()
            if devices:
                return devices
        return []

    def _windows_get_disks(self) -> list[DeviceInfo]:
        disks = []
        script = (
            "Get-Disk | "
            "Select-Object Number,FriendlyName,SerialNumber,BusType,Size,"
            "PartitionStyle,OperationalStatus,HealthStatus,IsBoot,IsSystem | "
            "ConvertTo-Json -Compress"
        )
        try:
            code, out, err = run_command(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                timeout=15,
            )
            if code != 0 or not out.strip():
                self.logger.warning("PowerShell disk query failed: " + err.strip())
                return []
            raw = json.loads(out)
            for item in json_or_list(raw):
                number = parse_int(item.get("Number"), -1)
                if number < 0:
                    continue
                size = parse_int(item.get("Size"), 0)
                bus = str(item.get("BusType") or "Unknown")
                friendly = str(item.get("FriendlyName") or "Unnamed disk")
                serial = str(item.get("SerialNumber") or "").strip()
                style = str(item.get("PartitionStyle") or "Unknown")
                health = str(item.get("HealthStatus") or "Unknown")
                op_status = str(item.get("OperationalStatus") or "Unknown")
                is_boot_disk = str(item.get("IsBoot")).lower() == "true"
                is_system_disk = str(item.get("IsSystem")).lower() == "true"
                removable_hint = bus.upper() == "USB"
                disks.append(
                    DeviceInfo(
                        number=number,
                        name=friendly,
                        size=size,
                        bus=bus,
                        partition_style=style,
                        health=health,
                        operational_status=op_status,
                        serial=serial,
                        is_boot=is_boot_disk,
                        is_system=is_system_disk,
                        removable_hint=removable_hint,
                        raw_path=fr"\\.\PhysicalDrive{number}",
                        source="PowerShell Get-Disk",
                    )
                )
            self.logger.log(f"Detected {len(disks)} physical disk(s).")
        except Exception as exc:
            self.logger.warning(f"Windows disk enumeration error: {exc}")
        return disks


# --------------------------- Disk safety ---------------------------

class DiskSafety:
    @staticmethod
    def device_is_allowed(device: DeviceInfo) -> tuple[bool, str]:
        if not device.raw_path:
            return False, "No raw device path is available."
        if device.is_system:
            return False, "Windows marks this disk as the system disk."
        if device.is_boot:
            return False, "Windows marks this disk as a boot disk."
        if device.size <= 0:
            return False, "The selected disk reports no usable capacity."
        if is_windows():
            bus = str(device.bus or "Unknown").upper()
            if bus != "USB":
                return False, (
                    f"Protected target: Windows reports this disk as {device.bus}. "
                    "Select a USB device for FLUX flashing."
                )
        return True, "Device passed safety checks."

    @staticmethod
    def confirm_text(device: DeviceInfo) -> str:
        return f"ERASE DISK {device.number}"

    @staticmethod
    def image_fits(device: DeviceInfo, image_path: str) -> tuple[bool, str]:
        try:
            image_size = os.path.getsize(image_path)
        except OSError as exc:
            return False, str(exc)
        if image_size > device.size:
            return False, (
                f"Image is {format_bytes(image_size)}, but the target is only "
                f"{format_bytes(device.size)}."
            )
        return True, "Image fits on target."


# --------------------------- Win32 Raw Disk Writer --------------------------

class Win32RawWriter:
    """Handles raw sector writes with volume locking and dismounting for Windows."""

    GENERIC_READ = 0x80000000
    GENERIC_WRITE = 0x40000000
    FILE_SHARE_READ = 0x00000001
    FILE_SHARE_WRITE = 0x00000002
    OPEN_EXISTING = 3
    FSCTL_LOCK_VOLUME = 0x00090018
    FSCTL_DISMOUNT_VOLUME = 0x00090020
    FSCTL_ALLOW_EXTENDED_DASD_IO = 0x00090083

    def __init__(self, disk_number: int):
        self.disk_number = disk_number
        self.disk_handle = None
        self.vol_handles = []

    def _lock_and_dismount_volumes(self):
        # Lock and dismount all logical drives on this physical drive
        ps_cmd = (
            f"Get-Partition -DiskNumber {self.disk_number} | "
            "Select-Object -ExpandProperty AccessPaths"
        )
        try:
            code, out, _ = run_command(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_cmd]
            )
            if code == 0 and out.strip():
                for path in out.strip().splitlines():
                    path = path.strip()
                    # Use Volume GUID paths to ensure unlettered partitions are also locked
                    if path.startswith("\\\\?\\Volume") and path.endswith("\\"):
                        vol_path = path[:-1]
                        h_vol = ctypes.windll.kernel32.CreateFileW(
                            vol_path,
                            self.GENERIC_READ | self.GENERIC_WRITE,
                            self.FILE_SHARE_READ | self.FILE_SHARE_WRITE,
                            None,
                            self.OPEN_EXISTING,
                            0,
                            None,
                        )
                        if h_vol != -1 and h_vol != 0:
                            bytes_ret = ctypes.c_ulong()
                            ctypes.windll.kernel32.DeviceIoControl(
                                h_vol, self.FSCTL_LOCK_VOLUME, None, 0, None, 0, ctypes.byref(bytes_ret), None
                            )
                            ctypes.windll.kernel32.DeviceIoControl(
                                h_vol, self.FSCTL_DISMOUNT_VOLUME, None, 0, None, 0, ctypes.byref(bytes_ret), None
                            )
                            self.vol_handles.append(h_vol)
        except Exception:
            pass

    def open(self):
        self._lock_and_dismount_volumes()
        path = fr"\\.\PhysicalDrive{self.disk_number}"
        self.disk_handle = ctypes.windll.kernel32.CreateFileW(
            path,
            self.GENERIC_READ | self.GENERIC_WRITE,
            self.FILE_SHARE_READ | self.FILE_SHARE_WRITE,
            None,
            self.OPEN_EXISTING,
            0,
            None,
        )
        if self.disk_handle == -1 or self.disk_handle == 0:
            err = ctypes.GetLastError()
            raise PermissionError(f"Failed to open disk {path}. Win32 Error Code: {err}")

        # Bypass OS partition bounds checking for raw disk writes
        bytes_ret = ctypes.c_ulong()
        ctypes.windll.kernel32.DeviceIoControl(
            self.disk_handle, self.FSCTL_ALLOW_EXTENDED_DASD_IO, None, 0, None, 0, ctypes.byref(bytes_ret), None
        )

    def write(self, data: bytes):
        written = ctypes.c_ulong()
        success = ctypes.windll.kernel32.WriteFile(
            self.disk_handle,
            data,
            len(data),
            ctypes.byref(written),
            None,
        )
        if not success:
            err = ctypes.GetLastError()
            raise IOError(f"Raw write failed on physical disk. Win32 Error Code: {err}")
        return written.value

    def close(self):
        if self.disk_handle and self.disk_handle != -1:
            ctypes.windll.kernel32.CloseHandle(self.disk_handle)
            self.disk_handle = None
        # Release volume locks by closing their handles
        for h_vol in getattr(self, 'vol_handles', []):
            if h_vol and h_vol != -1:
                ctypes.windll.kernel32.CloseHandle(h_vol)
        self.vol_handles = []


# --------------------------- Flash engine --------------------------

class FlashCancelled(Exception):
    pass


class FlashEngine:
    def __init__(self, logger: FluxLogger):
        self.logger = logger

    def write(
        self,
        image_path: str,
        device: DeviceInfo,
        chunk_size: int,
        progress_callback,
        status_callback,
        stop_event: threading.Event,
        flush_event: threading.Event | None = None,
    ):
        okay, reason = DiskSafety.device_is_allowed(device)
        if not okay:
            raise PermissionError(reason)

        okay, reason = DiskSafety.image_fits(device, image_path)
        if not okay:
            raise ValueError(reason)

        total = os.path.getsize(image_path)
        if total <= 0:
            raise ValueError("The selected image is empty.")

        self.logger.log(f"Starting raw image write: {image_path} -> Disk {device.number}")
        started = time.time()
        written = 0
        next_report = 0

        # Enforce sector-aligned chunks (multiples of 512 bytes)
        aligned_chunk = (chunk_size // 512) * 512
        if aligned_chunk == 0:
            aligned_chunk = 512

        writer = Win32RawWriter(device.number)
        writer.open()

        try:
            with open(image_path, "rb") as source:
                while True:
                    if stop_event.is_set():
                        raise FlashCancelled("Write cancelled by user.")

                    chunk = source.read(aligned_chunk)
                    if not chunk:
                        break

                    # Zero-pad final chunk if not sector aligned
                    if len(chunk) % 512 != 0:
                        pad_len = 512 - (len(chunk) % 512)
                        chunk += b"\x00" * pad_len

                    writer.write(chunk)
                    written += len(chunk)

                    ratio = min(1.0, written / total) if total else 0
                    elapsed = max(0.001, time.time() - started)
                    rate = written / elapsed
                    eta = (total - written) / rate if rate else 0
                    progress_callback(
                        ratio,
                        min(written, total),
                        total,
                        rate,
                        eta,
                    )
                    if written >= next_report:
                        status_callback(
                            f"Writing {format_bytes(min(written, total))} / {format_bytes(total)}"
                        )
                        next_report = written + aligned_chunk * 16
        finally:
            writer.close()

        elapsed = time.time() - started
        status_callback(f"Write completed in {human_duration(elapsed)}.")
        self.logger.log(
            f"Write completed: {format_bytes(total)} in {human_duration(elapsed)}."
        )

    def verify(
        self,
        image_path: str,
        device: DeviceInfo,
        chunk_size: int,
        progress_callback,
        status_callback,
        stop_event: threading.Event,
    ):
        total = os.path.getsize(image_path)
        if total <= 0:
            raise ValueError("Cannot verify an empty image.")

        image_hash = hashlib.sha256()
        target_hash = hashlib.sha256()
        processed = 0
        started = time.time()

        aligned_chunk = (chunk_size // 512) * 512
        if aligned_chunk == 0:
            aligned_chunk = 512

        with open(image_path, "rb", buffering=0) as source:
            with open(device.raw_path, "rb", buffering=0) as target:
                while processed < total:
                    if stop_event.is_set():
                        raise FlashCancelled("Verification cancelled by user.")

                    want = min(aligned_chunk, total - processed)
                    source_chunk = source.read(want)
                    target_chunk = target.read(want)

                    if len(source_chunk) != len(target_chunk):
                        raise IOError(
                            "Verification failed: target returned fewer bytes than expected."
                        )

                    image_hash.update(source_chunk)
                    target_hash.update(target_chunk)
                    processed += len(source_chunk)

                    ratio = processed / total
                    elapsed = max(0.001, time.time() - started)
                    rate = processed / elapsed
                    eta = (total - processed) / rate if rate else 0
                    progress_callback(
                        ratio,
                        processed,
                        total,
                        rate,
                        eta,
                    )
                    status_callback(
                        f"Verifying {format_bytes(processed)} / {format_bytes(total)}"
                    )

        left = image_hash.hexdigest()
        right = target_hash.hexdigest()
        self.logger.log(f"Image SHA-256: {left}")
        self.logger.log(f"Target SHA-256: {right}")

        if left != right:
            raise IOError("Verification failed: SHA-256 hashes do not match.")

        self.logger.log("Verification successful.")
        status_callback("Verification complete — data matches the source image.")

    def inspect_image(self, path: str) -> dict:
        result = {
            "path": path,
            "size": 0,
            "sha256": "",
            "extension": Path(path).suffix.lower(),
            "filename": Path(path).name,
            "bootable_hint": False,
            "filesystem_hint": "Unknown",
        }
        size = os.path.getsize(path)
        result["size"] = size
        return result


# ------------------------------ UI helpers -------------------------

import math


XP_SKY = "#1a78e8"
XP_BLUE = "#0b5fd7"
XP_DARK_BLUE = "#073d93"
XP_DEEP_BLUE = "#05265f"
XP_GLOSS_TOP = "#69c8ff"
XP_GLOSS_MID = "#258cf1"
XP_GLOSS_BOTTOM = "#0b61d2"

AERO_BG = "#dfeeff"
AERO_PANEL = "#eef7ff"
AERO_LINE = "#78a8d8"
AERO_LINE_DARK = "#3d6ea8"
AERO_TEXT = "#102d4c"
AERO_MUTED = "#4c6680"
AERO_WHITE = "#ffffff"

STATUS_OK = "#16834a"
STATUS_ERROR = "#b72a3b"


def center_fixed_window(root, width=760, height=720):
    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    x = max(0, (sw - width) // 2)
    y = max(0, (sh - height) // 2)
    root.geometry(f"{width}x{height}+{x}+{y}")
    root.minsize(width, height)
    root.maxsize(width, height)
    root.resizable(False, False)


def _xp_vertical_gradient(canvas, x0, y0, x1, y1, top, bottom, steps=40):
    def hexrgb(value):
        value = value.lstrip("#")
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))

    a = hexrgb(top)
    b = hexrgb(bottom)
    height = max(1, y1 - y0)

    for i in range(steps):
        t = i / max(1, steps - 1)
        color = "#{:02x}{:02x}{:02x}".format(
            int(a[0] * (1 - t) + b[0] * t),
            int(a[1] * (1 - t) + b[1] * t),
            int(a[2] * (1 - t) + b[2] * t),
        )
        yy0 = y0 + int(height * i / steps)
        yy1 = y0 + int(height * (i + 1) / steps)
        canvas.create_rectangle(x0, yy0, x1, yy1, fill=color, outline="")


class AeroButton(tk.Canvas):
    def __init__(
        self,
        master,
        text="",
        command=None,
        width=120,
        height=32,
        accent=False,
        disabled=False,
    ):
        super().__init__(
            master,
            width=width,
            height=height,
            bg=master.cget("bg") if "bg" in master.keys() else AERO_PANEL,
            highlightthickness=0,
            bd=0,
            cursor="hand2" if not disabled else "arrow",
        )
        self.button_text = text
        self.command = command
        self.button_width = width
        self.button_height = height
        self.accent = accent
        self.disabled = disabled
        self.hover = False

        self.bind("<Enter>", self._enter)
        self.bind("<Leave>", self._leave)
        self.bind("<Button-1>", self._click)
        self._draw()

    def _enter(self, _event=None):
        if not self.disabled:
            self.hover = True
            self._draw()

    def _leave(self, _event=None):
        if not self.disabled:
            self.hover = False
            self._draw()

    def _click(self, _event=None):
        if self.disabled:
            return
        if callable(self.command):
            self.command()

    def set_state(self, disabled=False):
        self.disabled = bool(disabled)
        self.configure(cursor="arrow" if self.disabled else "hand2")
        self._draw()

    def _draw(self):
        self.delete("all")
        w = self.button_width
        h = self.button_height

        if self.disabled:
            top, bottom = "#bfd0e2", "#aebfd2"
            edge = "#93a9bf"
            fg = "#eef3f8"
        elif self.accent:
            top = XP_GLOSS_TOP if self.hover else "#51bbff"
            bottom = XP_GLOSS_MID if self.hover else XP_BLUE
            edge = "#0754ad"
            fg = "#ffffff"
        else:
            top = "#ffffff" if self.hover else "#edf6ff"
            bottom = "#bfd8ee" if self.hover else "#a7c3de"
            edge = "#547ea9"
            fg = AERO_TEXT

        self.create_rectangle(1, 1, w - 2, h - 2, fill=bottom, outline=edge)
        self.create_rectangle(2, 2, w - 2, h * 0.45, fill=top, outline="")
        self.create_rectangle(2, 2, w - 2, 3, fill="#ffffff", outline="")

        self.create_text(
            w / 2,
            h / 2 + 1,
            text=self.button_text,
            fill=fg,
            font=("Segoe UI", 9, "bold"),
        )


class AeroSelect(tk.Frame):
    def __init__(self, master, variable: StringVar, values, command=None, width=250):
        super().__init__(
            master,
            bg=AERO_PANEL,
            highlightthickness=1,
            highlightbackground=AERO_LINE_DARK,
            highlightcolor=XP_SKY,
            bd=0,
        )
        self.variable = variable
        self.values = list(values)
        self.command = command
        self.width = width

        self.value_label = tk.Label(
            self,
            text=self.variable.get(),
            bg=AERO_WHITE,
            fg=AERO_TEXT,
            anchor="w",
            font=("Segoe UI", 9),
            padx=8,
            pady=6,
            cursor="hand2",
        )
        self.value_label.pack(side="left", fill="both", expand=True)

        self.arrow = tk.Button(
            self,
            text="▼",
            bg=XP_BLUE,
            fg="#ffffff",
            activebackground=XP_SKY,
            activeforeground="#ffffff",
            relief="flat",
            bd=0,
            width=3,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
            command=self._open,
        )
        self.arrow.pack(side="right", fill="y")

        self.value_label.bind("<Button-1>", lambda _e: self._open())
        self.bind("<Button-1>", lambda _e: self._open())
        self.variable.trace_add("write", self._sync)

    def _sync(self, *_args):
        self.value_label.configure(text=self.variable.get())

    def set_values(self, values):
        self.values = list(values)
        self._sync()

    def _open(self):
        menu = tk.Menu(
            self,
            tearoff=False,
            bg=AERO_WHITE,
            fg=AERO_TEXT,
            activebackground=XP_BLUE,
            activeforeground="#ffffff",
            borderwidth=1,
            relief="solid",
            font=("Segoe UI", 9),
        )

        for item in self.values:
            menu.add_command(
                label=item,
                command=lambda choice=item: self._choose(choice),
            )

        try:
            x = self.winfo_rootx()
            y = self.winfo_rooty() + self.winfo_height()
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def _choose(self, value):
        self.variable.set(value)
        if callable(self.command):
            self.command(value)


class AeroPanel(tk.Frame):
    def __init__(self, master, **kwargs):
        super().__init__(
            master,
            bg=kwargs.pop("bg", AERO_PANEL),
            highlightthickness=1,
            highlightbackground=kwargs.pop("outline", AERO_LINE),
            bd=0,
            **kwargs,
        )


class AeroHeader(tk.Frame):
    def __init__(self, master, text, number=None, **kwargs):
        super().__init__(master, bg=XP_BLUE, bd=0, highlightthickness=0, **kwargs)
        self.canvas = tk.Canvas(
            self,
            height=25,
            bg=XP_BLUE,
            highlightthickness=0,
            bd=0,
        )
        self.canvas.pack(fill="x", expand=True)
        self._text = text
        self._number = number
        self.bind("<Configure>", self._paint)
        self.canvas.bind("<Configure>", self._paint)

    def _paint(self, _event=None):
        self.canvas.delete("all")
        w = max(10, self.canvas.winfo_width())
        h = max(30, self.canvas.winfo_height())
        _xp_vertical_gradient(
            self.canvas, 0, 0, w, h,
            XP_GLOSS_TOP, XP_GLOSS_BOTTOM, 30
        )
        self.canvas.create_line(0, h - 1, w, h - 1, fill=XP_DEEP_BLUE)
        self.canvas.create_text(
            10,
            h / 2,
            text=f"{self._number}  |  {self._text}" if self._number else self._text,
            anchor="w",
            fill="#ffffff",
            font=("Segoe UI", 9, "bold"),
        )


class GlassBanner(tk.Canvas):
    def __init__(self, master, width=720, height=118, **kwargs):
        super().__init__(
            master,
            width=width,
            height=height,
            bg=XP_DEEP_BLUE,
            highlightthickness=0,
            bd=0,
            **kwargs,
        )
        self.w = width
        self.h = height
        self.phase = 0.0
        self.stars = [
            ((i * 53) % 720, (i * 29) % 118, 1 + (i % 2))
            for i in range(42)
        ]
        self.bind("<Configure>", self._resize)
        self.after(80, self._animate)

    def _resize(self, event=None):
        self.w = max(200, self.winfo_width())
        self.h = max(80, self.winfo_height())

    def _animate(self):
        self.phase += 0.08
        self._draw()
        self.after(80, self._animate)

    def _draw(self):
        self.delete("all")
        _xp_vertical_gradient(
            self, 0, 0, self.w, self.h,
            "#031331", "#087ae0", 56
        )

        for x, y, size in self.stars:
            if x > self.w or y > self.h:
                continue
            self.create_oval(x, y, x + size, y + size, fill="#7edcff", outline="")

        self.create_text(
            self.w * 0.055,
            self.h * 0.45,
            text="FLUX",
            anchor="w",
            fill="#f6fdff",
            font=("Arial", max(31, int(self.h * 0.34)), "bold italic"),
        )
        self.create_text(
            self.w * 0.06,
            self.h * 0.79,
            text="USB FLASHING SOFTWARE",
            anchor="w",
            fill="#c6eeff",
            font=("Segoe UI", 9, "bold"),
        )


# ------------------------------ Dialogs ----------------------------

class ConfirmEraseDialog(Toplevel):
    def __init__(self, master, device: DeviceInfo):
        super().__init__(master)
        self.result = False
        self.device = device
        self.title("FLUX — Confirm target")
        self.configure(bg=AERO_BG)
        self.geometry("520x355")
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()

        top = tk.Canvas(self, height=46, bg=XP_BLUE, highlightthickness=0)
        top.pack(fill="x")
        _xp_vertical_gradient(top, 0, 0, 520, 46, XP_GLOSS_TOP, XP_BLUE, 35)
        top.create_text(
            18, 23,
            text="FLUX  •  TARGET CONFIRMATION",
            anchor="w",
            fill="#ffffff",
            font=("Segoe UI", 11, "bold"),
        )

        body = tk.Frame(self, bg=AERO_BG)
        body.pack(fill="both", expand=True, padx=20, pady=18)

        tk.Label(
            body,
            text="The selected disk will be overwritten.",
            bg=AERO_BG,
            fg=STATUS_ERROR,
            font=("Segoe UI", 13, "bold"),
        ).pack(anchor="w")

        tk.Label(
            body,
            text=device.safe_label,
            bg=AERO_BG,
            fg=AERO_TEXT,
            wraplength=460,
            justify="left",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w", pady=(8, 5))

        tk.Label(
            body,
            text=f"Type exactly: {DiskSafety.confirm_text(device)}",
            bg=AERO_BG,
            fg=AERO_TEXT,
            font=("Consolas", 9, "bold"),
        ).pack(anchor="w")

        self.entry = tk.Entry(
            body,
            bg="#ffffff",
            fg=AERO_TEXT,
            insertbackground=AERO_TEXT,
            relief="solid",
            bd=1,
            font=("Consolas", 10),
        )
        self.entry.pack(fill="x", pady=(5, 14), ipady=5)
        self.entry.focus_set()

        row = tk.Frame(body, bg=AERO_BG)
        row.pack(fill="x")

        AeroButton(
            row,
            "CANCEL",
            self._cancel,
            width=110,
            height=30,
        ).pack(side="right", padx=(8, 0))

        AeroButton(
            row,
            "ERASE + FLASH",
            self._confirm,
            width=145,
            height=30,
            accent=True,
        ).pack(side="right")

    def _confirm(self):
        expected = DiskSafety.confirm_text(self.device)
        if self.entry.get().strip().upper() != expected:
            messagebox.showerror(
                "FLUX",
                "The confirmation phrase does not match.",
                parent=self,
            )
            return
        self.result = True
        self.destroy()

    def _cancel(self):
        self.result = False
        self.destroy()

    @classmethod
    def show(cls, master, device):
        dialog = cls(master, device)
        master.wait_window(dialog)
        return dialog.result


# ----------------------------- Main app ----------------------------

class FluxApp:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title(f"FLUX — {APP_TAGLINE}")
        self.root.configure(bg=AERO_BG)
        center_fixed_window(root, 760, 560)

        self.settings_store = SettingsStore()
        self.settings = self.settings_store.load()
        self.logger = FluxLogger(self.settings)
        self.enumerator = DeviceEnumerator(self.logger)
        self.engine = FlashEngine(self.logger)

        self.devices: dict[str, DeviceInfo] = {}
        self.plan = FlashPlan()

        self.stop_event = threading.Event()
        self.flush_event = threading.Event()
        self.operation_queue: queue.Queue = queue.Queue()
        self.worker: threading.Thread | None = None
        self.operation_running = False

        self.image_var = StringVar(value="")
        self.device_var = StringVar(value="Select a device…")

        self.partition_var = StringVar(value="GPT")
        self.target_var = StringVar(value="UEFI")
        self.fs_var = StringVar(value="Large FAT32")
        self.cluster_var = StringVar(value="Default")
        self.label_var = StringVar(value="FLUX")
        self.verify_var = BooleanVar(value=self.settings.verify_after_write)

        self.status_var = StringVar(value="READY")
        self.status_detail_var = StringVar(
            value="Select a USB device and an image to begin."
        )
        self.percent_var = StringVar(value="0%")
        self.speed_var = StringVar(value="0 B/s")
        self.eta_var = StringVar(value="ETA —")

        self.current_image_info: dict = {}
        self.selected_device: DeviceInfo | None = None

        self._build_main_window()
        self._refresh_devices()
        self._pump_events()

        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.logger.log(f"{APP_NAME} v{APP_VERSION} started.")
        self.logger.log(f"Administrator/root: {is_admin()}")

    def _build_main_window(self):
        shell = tk.Frame(
            self.root,
            bg=AERO_BG,
            highlightthickness=1,
            highlightbackground="#335f91",
        )
        shell.pack(fill="both", expand=True, padx=7, pady=7)

        content = tk.Frame(shell, bg=AERO_BG)
        content.pack(fill="both", expand=True, padx=8, pady=5)

        self.banner = GlassBanner(content, height=108)
        self.banner.pack(fill="x", pady=(0, 8))

        self._build_device_section(content)
        self._build_boot_section(content)
        self._build_options_section(content)
        self._build_status_section(content)

    def _section(self, parent, number, text):
        outer = AeroPanel(parent, bg=AERO_PANEL)
        outer.pack(fill="x", pady=3)
        AeroHeader(outer, text, number).pack(fill="x")
        return outer

    def _build_device_section(self, parent):
        panel = self._section(parent, 1, "DEVICE")
        body = tk.Frame(panel, bg=AERO_PANEL, padx=9, pady=7)
        body.pack(fill="x")

        row = tk.Frame(body, bg=AERO_PANEL)
        row.pack(fill="x")

        self.device_select = AeroSelect(
            row,
            self.device_var,
            ["No devices detected"],
            command=self._device_choice,
        )
        self.device_select.pack(side="left", fill="x", expand=True)

        self.refresh_button = AeroButton(
            row,
            "REFRESH",
            self._refresh_devices,
            width=84,
            height=29,
        )
        self.refresh_button.pack(side="left", padx=(6, 0))

        self.device_detail = tk.Label(
            body,
            text="No target selected.",
            bg=AERO_PANEL,
            fg=AERO_MUTED,
            anchor="w",
            font=("Segoe UI", 7),
        )
        self.device_detail.pack(fill="x", pady=(2, 0))

    def _build_boot_section(self, parent):
        panel = self._section(parent, 2, "BOOT SELECTION")
        body = tk.Frame(panel, bg=AERO_PANEL, padx=9, pady=7)
        body.pack(fill="x")

        row = tk.Frame(body, bg=AERO_PANEL)
        row.pack(fill="x")

        self.image_entry = tk.Entry(
            row,
            bg="#ffffff",
            fg=AERO_TEXT,
            insertbackground=AERO_TEXT,
            relief="solid",
            bd=1,
            highlightthickness=1,
            highlightbackground=AERO_LINE_DARK,
            highlightcolor=XP_SKY,
            font=("Segoe UI", 9),
        )
        self.image_entry.pack(side="left", fill="x", expand=True, ipady=4)

        self.image_var.trace_add(
            "write",
            lambda *_args: self._sync_image_entry(),
        )

        AeroButton(
            row,
            "SELECT…",
            self._choose_image,
            width=88,
            height=29,
            accent=True,
        ).pack(side="left", padx=(6, 0))

    def _build_options_section(self, parent):
        panel = self._section(parent, 3, "IMAGE / BOOT OPTIONS")
        body = tk.Frame(panel, bg=AERO_PANEL, padx=9, pady=7)
        body.pack(fill="x")

        grid = tk.Frame(body, bg=AERO_PANEL)
        grid.pack(fill="x")

        fields = [
            ("IMAGE MODE", "image_mode", ["Raw image (DD)", "ISO image mode"]),
            ("PARTITION SCHEME", "partition", ["GPT", "MBR", "Use image layout"]),
            ("TARGET SYSTEM", "target", ["UEFI", "BIOS or UEFI-CSM", "BIOS"]),
            ("FILE SYSTEM", "filesystem", ["Large FAT32", "FAT32", "NTFS", "exFAT"]),
        ]

        for index, (label, kind, values) in enumerate(fields):
            cell = tk.Frame(grid, bg=AERO_PANEL)
            cell.grid(row=0, column=index, sticky="ew", padx=2)

            tk.Label(
                cell,
                text=label,
                bg=AERO_PANEL,
                fg=XP_DARK_BLUE,
                anchor="w",
                font=("Segoe UI", 6, "bold"),
            ).pack(fill="x", pady=(0, 1))

            if kind == "image_mode":
                self.image_mode_var = StringVar(value="Raw image (DD)")
                variable = self.image_mode_var
            elif kind == "partition":
                variable = self.partition_var
            elif kind == "target":
                variable = self.target_var
            else:
                variable = self.fs_var

            AeroSelect(cell, variable, values).pack(fill="x")

        for col in range(4):
            grid.grid_columnconfigure(col, weight=1)

    def _build_status_section(self, parent):
        panel = self._section(parent, 4, "READY TO FLASH")
        body = tk.Frame(panel, bg=AERO_PANEL, padx=9, pady=7)
        body.pack(fill="x")

        top = tk.Frame(body, bg=AERO_PANEL)
        top.pack(fill="x")

        tk.Label(
            top,
            textvariable=self.status_var,
            bg=AERO_PANEL,
            fg=STATUS_OK,
            anchor="w",
            font=("Segoe UI", 8, "bold"),
        ).pack(side="left")

        tk.Label(
            top,
            textvariable=self.percent_var,
            bg=AERO_PANEL,
            fg=XP_DARK_BLUE,
            anchor="e",
            font=("Consolas", 8, "bold"),
        ).pack(side="right")

        self.progress = ttk.Progressbar(
            body,
            mode="determinate",
            maximum=100,
            value=0,
            length=600,
        )
        self.progress.pack(fill="x", pady=(3, 3))

        actions = tk.Frame(body, bg=AERO_PANEL)
        actions.pack(fill="x", pady=(8, 2))

        self.cancel_button = AeroButton(
            actions,
            "CANCEL",
            self._cancel_operation,
            width=86,
            height=28,
            accent=False,
            disabled=True,
        )
        self.cancel_button.pack(side="right", padx=(6, 0))

        self.start_button = AeroButton(
            actions,
            "START FLASH",
            self._start_flash,
            width=150,
            height=30,
            accent=True,
        )
        self.start_button.pack(side="right")

    def _pump_events(self):
        try:
            while True:
                event = self.operation_queue.get_nowait()
                self._handle_worker_event(event)
        except queue.Empty:
            pass
        self.root.after(80, self._pump_events)

    def _sync_image_entry(self):
        path = self.image_var.get()
        if self.image_entry.get() != path:
            self.image_entry.delete(0, END)
            self.image_entry.insert(0, path)

    def _refresh_devices(self):
        if self.operation_running:
            return

        found = self.enumerator.enumerate()
        self.devices.clear()

        labels = []
        self.device_key_by_label: dict[str, str] = {}

        for index, device in enumerate(found):
            key = f"disk-{device.number}-{index}"
            self.devices[key] = device
            label = f"Disk {device.number}: {device.name}  •  {format_bytes(device.size)}"
            if device.bus:
                label += f"  •  {device.bus}"
            labels.append(label)
            self.device_key_by_label[label] = key

        if labels:
            self.device_select.set_values(labels)
            self.device_var.set(labels[0])
            self._device_choice(labels[0])
            self.status_var.set("READY")
        else:
            labels = ["No devices detected"]
            self.device_select.set_values(labels)
            self.device_var.set(labels[0])
            self.selected_device = None
            self.status_var.set("NO DEVICE")

    def _device_choice(self, value):
        key = self.device_key_by_label.get(value)
        device = self.devices.get(key) if key else None
        self.selected_device = device
        self.plan.device_number = device.number if device else None

    def _choose_image(self):
        if self.operation_running:
            return
        path = filedialog.askopenfilename(
            title="FLUX — Select boot image",
            filetypes=[("Disk images", "*.iso *.img *.bin *.vhd *.vhdx"), ("All files", "*.*")],
        )
        if path:
            self.image_var.set(path)

    def _start_flash(self):
        if self.operation_running:
            return

        image_path = self.image_var.get().strip()
        device = self.selected_device

        if not image_path or not os.path.exists(image_path):
            messagebox.showerror("FLUX", "Please select a valid image file.", parent=self.root)
            return

        if not device:
            messagebox.showerror("FLUX", "Please select a target USB device.", parent=self.root)
            return

        if not ConfirmEraseDialog.show(self.root, device):
            return

        self._begin_worker(image_path, device)

    def _begin_worker(self, image_path: str, device: DeviceInfo):
        self.operation_running = True
        self.stop_event.clear()
        self.start_button.set_state(True)
        self.cancel_button.set_state(False)
        self.refresh_button.set_state(True)

        self.worker = threading.Thread(
            target=self._worker_main,
            args=(image_path, device, self.verify_var.get()),
            daemon=True,
        )
        self.worker.start()

    def _worker_main(self, image_path, device, verify):
        chunk_size = max(1, int(self.settings.chunk_size_mb)) * 1024 * 1024
        try:
            self.engine.write(
                image_path=image_path,
                device=device,
                chunk_size=chunk_size,
                progress_callback=lambda ratio, done, total, rate, eta:
                    self.operation_queue.put(("progress", ratio, done, total, rate, eta)),
                status_callback=lambda text:
                    self.operation_queue.put(("write_status", text)),
                stop_event=self.stop_event,
            )
            self.operation_queue.put(("success",))
        except Exception as exc:
            self.operation_queue.put(("error", str(exc)))

    def _handle_worker_event(self, event):
        kind = event[0]
        if kind == "progress":
            _, ratio, done, total, rate, eta = event
            pct = max(0, min(100, ratio * 100))
            self.progress["value"] = pct
            self.percent_var.set(f"{pct:.1f}%")
        elif kind == "success":
            self.operation_running = False
            self.start_button.set_state(False)
            self.cancel_button.set_state(True)
            self.progress["value"] = 100
            self.percent_var.set("100%")
            messagebox.showinfo("FLUX", "Flashing complete successfully!", parent=self.root)
        elif kind == "error":
            self.operation_running = False
            self.start_button.set_state(False)
            self.cancel_button.set_state(True)
            messagebox.showerror("FLUX Flash Error", event[1], parent=self.root)

    def _cancel_operation(self):
        if self.operation_running:
            self.stop_event.set()

    def _on_close(self):
        if self.operation_running:
            messagebox.showwarning("FLUX", "Cancel the active flash before closing.", parent=self.root)
            return
        self.root.destroy()


# ------------------------------ Startup ----------------------------

def startup():
    # Prompt for administrator privilege at launch before opening GUI
    if is_windows() and not is_admin():
        if not relaunch_as_administrator():
            messagebox.showerror(
                "FLUX — Elevation Required",
                "FLUX requires Administrator access to perform raw disk operations.\n"
                "Please accept the UAC prompt or run as Administrator.",
            )
            sys.exit(1)
        sys.exit(0)

    root = Tk()
    FluxApp(root)
    root.mainloop()


if __name__ == "__main__":
    startup()