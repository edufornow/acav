================================================================================
                              FLUX - OPERATING MANUAL
================================================================================

Welcome to Flux! This guide contains the necessary steps to set up, install, 
and operate Flux on a Windows environment.

--------------------------------------------------------------------------------
1. PREREQUISITES
--------------------------------------------------------------------------------
To run Flux on Windows, you must have Python installed on your system. 

• Python: Download and install Python 3.10 or newer from https://www.python.org/
  *CRITICAL STEP:* During the Windows installation process for Python, make sure 
  to check the box that says "Add Python.exe to PATH" at the bottom of the 
  installer window before clicking "Install Now". 

• Git (Optional but recommended): For downloading the repository easily.

--------------------------------------------------------------------------------
2. INSTALLATION & SETUP
--------------------------------------------------------------------------------
Follow these steps to set up Flux on your Windows machine:

1. Open Command Prompt or PowerShell.
2. Navigate to the folder where you have extracted or cloned the Flux files.
   (e.g., cd C:\Users\YourName\Documents\Flux)

3. (Recommended) Create a virtual environment to keep your dependencies clean:
   python -m venv venv

4. Activate the virtual environment:
   venv\Scripts\activate

5. Install the required dependencies:
   pip install -r requirements.txt

--------------------------------------------------------------------------------
3. OPERATING MANUAL (HOW TO RUN)
--------------------------------------------------------------------------------
Once your setup is complete, follow these steps every time you want to run Flux:

1. Open Command Prompt or PowerShell.
2. Navigate to your Flux directory:
   cd path\to\your\flux\folder

3. Activate your virtual environment (if you created one):
   venv\Scripts\activate

4. Run the main Flux script:
   python main.py 
   (Note: If your main script has a different name, replace 'main.py' with 
   the correct filename, e.g., 'python flux.py').

5. Follow any on-screen prompts or terminal instructions to interact with Flux.
   To exit the program, you can typically press Ctrl + C in the terminal.

--------------------------------------------------------------------------------
4. TROUBLESHOOTING
--------------------------------------------------------------------------------
• "Python is not recognized as an internal or external command": 
  This means Python was not added to your system's PATH. Re-run the Python 
  installer, select "Modify", and ensure "Add Python to environment variables" 
  is checked.

• "ModuleNotFoundError": 
  This means a required package is missing. Ensure you have activated your 
  virtual environment and run 'pip install -r requirements.txt' successfully.
================================================================================